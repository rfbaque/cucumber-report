module.exports = {
  default: {
    paths: ["test/features/**/*.feature"],
    require: ["src/hook/**/*.ts", "test/steps/**/*.ts"],
    requireModule: ["ts-node/register/transpile-only"],
    format: [
      "progress",
      "json:test-results/cucumber-report.json"
    ],
    formatOptions: { snippetInterface: "async-await" },
    publishQuiet: true
  }
};
