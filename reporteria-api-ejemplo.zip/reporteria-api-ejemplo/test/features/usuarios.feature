@api @fake
Feature: Consulta de usuarios
  Como consumidor de la API
  Quiero consultar un usuario
  Para validar la respuesta del servicio

  @TestCaseId=001
  Scenario: Consultar un usuario existente
    Given que existe el usuario con id 1
    When consulto el endpoint GET "/usuarios/1"
    Then el código de respuesta debe ser 200
    And la respuesta contiene el nombre "Ada Lovelace"

  # Desbloquear para que el reporte de pruebas genere un escenario fallido
  # @TestCaseId=002 
  # Escenario: Consultar un usuario inexistente
  #   Given que el usuario con id 999 no existe
  #   When consulto el endpoint GET "/usuarios/999"
  #   Then el código de respuesta debe ser 200
