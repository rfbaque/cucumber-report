import assert from "node:assert/strict";
import { Given, Then, When } from "@cucumber/cucumber";
import type { ApiWorld } from "../../src/hook/world";

Given("que existe el usuario con id {int}", function (this: ApiWorld, id: number) {
  assert.equal(id, 1, "El endpoint fake solo contiene el usuario 1");
});

Given("que el usuario con id {int} no existe", function (this: ApiWorld, id: number) {
  assert.notEqual(id, 1, "Este escenario valida un usuario inexistente");
});

When("consulto el endpoint GET {string}", async function (this: ApiWorld, path: string) {
  const url = `${this.baseUrl}${path}`;
  this.request = { method: "GET", url };

  const result = await fetch(url);
  this.response = { status: result.status, body: await result.json() };
});

Then("el código de respuesta debe ser {int}", function (this: ApiWorld, expected: number) {
  assert.equal(this.response?.status, expected);
});

Then("la respuesta contiene el nombre {string}", function (this: ApiWorld, expected: string) {
  const body = this.response?.body as { nombre?: string } | undefined;
  assert.equal(body?.nombre, expected);
});
