import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

fs.rmSync(path.resolve("test-results"), { recursive: true, force: true });
fs.mkdirSync(path.resolve("test-results"), { recursive: true });

const cucumberBin = path.resolve("node_modules", ".bin", process.platform === "win32" ? "cucumber-js.cmd" : "cucumber-js");
const tests = spawnSync(cucumberBin, [], { stdio: "inherit", shell: process.platform === "win32" });

const report = spawnSync(process.execPath, ["-r", "ts-node/register/transpile-only", "src/config/reporte/reporte.ts"], {
  stdio: "inherit"
});

process.exit(report.status || tests.status || 0);
