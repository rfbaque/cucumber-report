export const PDF_STYLES = `
  html, body { background: #fff !important; }
  body { padding-top: 18px; }
  .generated-on { display: none !important; }
  img { max-width: 100%; height: auto; }

  .row.steps {
    display: flex !important;
    flex-wrap: wrap !important;
    align-items: flex-start !important;
    gap: 10px !important;
    margin: 0 0 9px !important;
    padding: 0 !important;
    color: #344054 !important;
    font: 12px/1.45 "Segoe UI", Roboto, Arial, sans-serif !important;
  }
  .pdf-step-status { flex: 0 0 14px; color: #00a443; font-size: 15px; font-weight: 700; }
  .pdf-step-status.failed { color: #d92d20; }
  .pdf-step-status.skipped { color: #f0ad4e; }
  .row.steps > .text { display: flex !important; flex: 1 !important; gap: 4px !important; min-width: 0 !important; overflow-wrap: anywhere !important; }
  .row.steps > .collapse { flex: 1 0 100% !important; width: 100% !important; min-width: 0 !important; overflow: hidden !important; }
  .row.steps pre.info.show-modal { width: 100% !important; max-width: 100% !important; white-space: pre-wrap !important; overflow-wrap: anywhere !important; word-break: break-word !important; overflow: hidden !important; }
  .row.steps .keyword { color: #98a2b3 !important; font-weight: 600 !important; }
  .row.steps .step-duration { margin-left: auto !important; padding-left: 16px !important; color: #98a2b3 !important; white-space: nowrap !important; }

  .pdf-scenario { margin: 38px 0 26px !important; padding: 0 !important; border: 0 !important; background: transparent !important; box-shadow: none !important; break-inside: avoid-page !important; }
  .pdf-scenario-card { border: .35px solid rgba(52,58,70,.16) !important; border-radius: 10px !important; background: #fff !important; break-before: avoid-page !important; }
  .pdf-scenario-card > .panel-collapse > .panel-body { padding: 18px 18px 22px !important; }
  .pdf-scenario-header { position: relative !important; margin: 0 !important; padding: 10px 14px !important; border-radius: 10px 10px 0 0 !important; background: linear-gradient(90deg,#f5f5f5,#fff) !important; break-after: avoid-page !important; }
  .pdf-scenario-header + .panel-collapse { break-before: avoid-page !important; }
  .pdf-scenario-top { display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; break-after: avoid-page !important; }
  .pdf-case-id, .pdf-result, .pdf-http-status { font: 700 13px "Segoe UI", Roboto, Arial, sans-serif; text-align: center; }
  .pdf-case-id { display: inline-block; padding: 4px 12px; border-radius: 14px; background: #343a46; color: #fff; }
  .pdf-result { position: absolute; top: 8px; right: 14px; min-width: 84px; padding: 4px 14px; border-radius: 14px; background: #e6f6ed; color: #009b45; }
  .pdf-result.failed { background: #feeceb; color: #d92d20; }
  .pdf-scenario-title { padding-right: 105px; color: #303746; font: 700 15px/1.35 "Segoe UI", Roboto, Arial, sans-serif; }

  .pdf-data-grid { display: grid; grid-template-columns: minmax(0,1fr) minmax(0,1.35fr); align-items: start; gap: 18px; margin-top: 20px; padding-top: 4px; }
  .pdf-data-grid > section { min-width: 0; }
  .pdf-data-title { display: flex; align-items: center; justify-content: space-between; height: 24px; margin-bottom: 7px; color: #98a2b3; font: 600 12px "Segoe UI", Roboto, Arial, sans-serif; letter-spacing: .35px; }
  .pdf-http-status { min-width: 58px; padding: 3px 10px; border-radius: 12px; background: #e6f6ed; color: #009b45; }
  .pdf-json { margin: 0 !important; padding: 14px 16px !important; border: 0 !important; border-radius: 10px !important; background: #f7f8fa !important; color: #172b4d !important; font: 11px/1.5 Consolas,"Courier New",monospace !important; white-space: pre-wrap !important; overflow-wrap: anywhere !important; }

  .panel.panel-default { border: 0 !important; box-shadow: none !important; }
  .panel-heading { border: 0 !important; }
  .feature-passed > div > .panel > .panel-heading,
  .feature-failed > div > .panel > .panel-heading { font-family: Arial,sans-serif !important; font-weight: 400 !important; break-inside: avoid-page !important; break-after: avoid-page !important; }
  .feature-passed > div > .panel > .panel-heading b,
  .feature-failed > div > .panel > .panel-heading b { font-weight: 600 !important; }
  .feature-passed > div > .panel > .panel-collapse > .panel-body > .pdf-scenario:first-of-type,
  .feature-failed > div > .panel > .panel-collapse > .panel-body > .pdf-scenario:first-of-type { margin-top: 6px !important; break-before: avoid-page !important; }
  .feature-passed > div > .panel > .panel-heading .glyphicon-chevron-right,
  .feature-failed > div > .panel > .panel-heading .glyphicon-chevron-right { display: none !important; }
  .panel.panel-default.pdf-metadata { overflow: hidden; margin: 18px 0 22px; border: .6px solid rgba(52,58,70,.13) !important; border-radius: 8px !important; background: #fff !important; color: #344054 !important; }
  .pdf-metadata > .panel-heading { padding: 9px 14px !important; border-bottom: .1px solid rgba(52,58,70,.06) !important; background: #f8f9fa !important; color: #303746 !important; }
  .pdf-metadata > .panel-heading .panel-title, .pdf-metadata > .panel-heading a { margin: 0 !important; padding: 0 !important; }
  .pdf-metadata > .panel-heading b { font: 600 15px "Segoe UI",Roboto,Arial,sans-serif !important; }
  .pdf-metadata > #logOutput { border: 0 !important; background: transparent !important; }
  .pdf-metadata #logOutput .panel-body { padding: 0 !important; }
  .pdf-metadata #logOutput .panel-body > .row { display: grid !important; grid-template-columns: repeat(3,minmax(0,1fr)) !important; gap: 0 !important; }
  .pdf-metadata .metadata { padding: 12px 14px !important; border: 0 !important; border-right: .1px solid rgba(52,58,70,.06) !important; border-bottom: .1px solid rgba(52,58,70,.06) !important; color: #344054 !important; font: 600 13px/1.3 "Segoe UI",Roboto,Arial,sans-serif !important; }
  .pdf-metadata .metadata > div { color: #92959a !important; }
  .pdf-metadata .metadata strong { display: block; margin-bottom: 2px; color: #55585d !important; font-size: 13px !important; line-height: 1.1 !important; font-weight: 700 !important; }
  .pdf-metadata .pdf-meta-1 { grid-column: 1 / 3 !important; grid-row: 2 !important; overflow-wrap: anywhere; } 
  .pdf-metadata .pdf-meta-1 > div { color: #92959a !important; font: 600 13px/1.3 "Segoe UI",Roboto,Arial,sans-serif !important; }
  .pdf-metadata .pdf-meta-2 { grid-column: 1 !important; grid-row: 1 !important; }
  .pdf-metadata .pdf-meta-3 { grid-column: 2 !important; grid-row: 1 !important; }
  .pdf-metadata .pdf-meta-4 { grid-column: 3 !important; grid-row: 1 !important; }
  .pdf-metadata .pdf-meta-5 { grid-column: 1 / 4 !important; grid-row: 3 !important; border-bottom: 0 !important; }
  .pdf-metadata .pdf-meta-6 { grid-column: 3 !important; grid-row: 2 !important; }
  #logOutput table, #logOutput td { border: 0 !important; }
`;

export const headerTemplate = (logo: string, title: string, application: string) => `
  <table style="width:90%;margin:0 5% 20px;border-collapse:collapse;font:10px Helvetica,Arial,sans-serif;border:.2px solid #f5f5f5">
    <tr>
      <td rowspan="2" style="width:20%;padding:4px;border:.2px solid #f5f5f5"><img src="data:image/png;base64,${logo}" style="height:25px;vertical-align:middle"></td>
      <td style="width:60%;text-align:center;padding:4px;border:.2px solid #f5f5f5"><b>${title.toUpperCase()}</b><div style="padding-top:5px;color:#666;font-weight:bold">${application.toUpperCase()}</div></td>
      <td rowspan="2" style="width:20%;text-align:right;padding:4px;color:#555;border:.2px solid #f5f5f5">Página <span class="pageNumber"></span> de <span class="totalPages"></span></td>
    </tr>
    
  </table>`;
