import * as report from "cucumber-html-reporter";
import fs from "node:fs";
import path from "node:path";
import * as dotenv from "dotenv";
import { chromium } from "playwright/test";
import { PDF_STYLES, headerTemplate } from "./pdfStyles";

if (process.env.ENV) dotenv.config({ path: process.env.REPORT_ENV_FILE || `src/helper/env/.env.${process.env.ENV}` });

const NOMBRE_REPORTE = "Pruebas Automatizadas QA - API Ejemplo - Desarrollo";
console.log(`##vso[task.setvariable variable=REPORT_NAME]${NOMBRE_REPORTE}`);

const PERFILES = {
  apiEjemplo: { application: "API de Usuarios - Ejemplo", baseUrl: "http://127.0.0.1:3100" },
} as const;
 
const activos = [PERFILES.apiEjemplo];
 
const application = activos.map((p) => p.application).join(" / ");
const url = activos.map((p) => p.baseUrl).join(" | ");
 
const CONFIG = {
  title: process.env.REPORT_TITLE || "Informe de Pruebas Automatizadas",
  application: process.env.REPORT_APPLICATION || application,
  url: process.env.REPORT_URL || url,
  platform: process.env.REPORT_PLATFORM || "API REST",
  environment: process.env.REPORT_ENVIRONMENT || "Local",
  owner: process.env.AUTOMATIZADOR || "Equipo de Automatización"
};

const PATHS = {
  html: path.resolve(`test-results/${NOMBRE_REPORTE}.html`),
  pdf: path.resolve(`test-results/${NOMBRE_REPORTE}.pdf`),
  json: process.env.ARCHIVO_REPORTE_JSON || "test-results/cucumber-report.json",
};

const logo = fs.readFileSync(path.resolve(process.env.REPORT_LOGO || path.join(__dirname, "logoBg.png")), "base64");

function fecha(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function theme(): "bootstrap" | "hierarchy" | "foundation" | "simple" {
  const themes = ["bootstrap", "hierarchy", "foundation", "simple"] as const;
  const selected = process.env.TEMA_REPORTE as (typeof themes)[number];
  return themes.includes(selected) ? selected : "bootstrap";
}

async function styleMetadata(): Promise<void> {
  const html = await fs.promises.readFile(PATHS.html, "utf8");
  const css = `<style>
    #logOutput .panel-body>.row{display:grid;grid-template-columns:minmax(0,3fr) minmax(0,2fr);gap:12px 16px;margin:0}
    #logOutput .metadata{width:auto!important;float:none!important;padding:0;min-width:0}
    #logOutput .metadata>div{float:none!important;text-align:left;overflow-wrap:anywhere}
    #logOutput .metadata:has(.pull-left){grid-column:1}
    #logOutput .metadata:has(.pull-right-lg){grid-column:2}
  </style>`;
  await fs.promises.writeFile(PATHS.html, html.replace("</head>", `${css}</head>`));
}

export async function generarReporteHTML(): Promise<void> {
  report.generate({
    brandTitle: " ",
    columnLayout: 1,
    theme: theme(),
    name: CONFIG.title,
    jsonFile: PATHS.json,
    output: PATHS.html,
    reportSuiteAsScenarios: true,
    scenarioTimestamp: false,
    launchReport: process.env.PREVISUALIZAR_REPORTE === "true",
    reportMetadataTitle: "Detalles de la Ejecución",
    metadata: {   
      Url: CONFIG.url,
      Aplicación: CONFIG.application,
      Plataforma: CONFIG.platform,
      Ambiente: CONFIG.environment,
      "Responsable de la Automatización": CONFIG.owner,
      "Fecha": fecha(),
    },
    storeScreenshots: false,
    screenshotsDirectory: "test-results/screenshots/",
    failedSummaryReport: false,
  } as any);
  await styleMetadata();
}

function transformReport(page: import("playwright/test").Page): Promise<void> {
  return page.evaluate(() => {
    document.querySelectorAll<HTMLElement>(".collapse").forEach((element) => {
      element.classList.add("show");
      element.style.display = "block";
    });

    const metadata = document.querySelector<HTMLElement>("#logOutput");
    metadata?.parentElement?.classList.add("pdf-metadata");
    const metadataTitle = metadata?.parentElement?.querySelector<HTMLElement>(".panel-heading b");
    if (metadataTitle) metadataTitle.parentElement!.innerHTML = "<b>Detalles de la Ejecución</b>";
    metadata?.querySelectorAll<HTMLElement>(".metadata").forEach((item, index) => {
      item.classList.add(`pdf-meta-${index + 1}`);
      const title = item.querySelector<HTMLElement>("strong");
      if (title) title.textContent = title.textContent?.replace(":", "").trim() || "";
    });

    document.querySelectorAll<HTMLElement>('[id^="collapseScenario"]').forEach((scenario) => {
      const panel = scenario.parentElement;
      const heading = panel?.querySelector<HTMLElement>(":scope > .panel-heading");
      const body = scenario.querySelector<HTMLElement>(":scope > .panel-body");
      if (!panel || !heading || !body) return;

      const tags = Array.from(heading.querySelectorAll(".tag")).map((tag) => tag.textContent?.trim() || "");
      const tag = tags.find((value) => /^@TestCaseId=/i.test(value)) || tags[0] || "";
      const caseId = tag.replace(/^@TestCaseId=/i, "TC-").replace(/^@/, "");
      const title = (heading.querySelector<HTMLElement>('a > div > div[style*="padding-right"]')?.textContent || "")
        .replace(/^\s*Scenario(?: Outline)?:\s*/, "").trim();
      const failed = Boolean(heading.querySelector(".label-danger"));

      panel.classList.add("pdf-scenario");
      heading.className = `pdf-scenario-header${failed ? " failed" : ""}`;
      heading.innerHTML = `<div class="pdf-scenario-top"><span class="pdf-case-id"></span></div>
        <div class="pdf-scenario-title"></div><span class="pdf-result${failed ? " failed" : ""}">${failed ? "Failed" : "Passed"}</span>`;
      heading.querySelector<HTMLElement>(".pdf-case-id")!.textContent = caseId;
      heading.querySelector<HTMLElement>(".pdf-scenario-title")!.textContent = title;

      body.querySelectorAll<HTMLElement>(".row.steps").forEach((step) => {
        const table = step.querySelector<HTMLTableElement>("table");
        const cells = table?.querySelectorAll<HTMLTableCellElement>("tbody td");
        if (cells && cells.length >= 3) {
          const grid = document.createElement("div");
          grid.className = "pdf-data-grid";
          [0, 1].forEach((index) => {
            const section = document.createElement("section");
            const label = document.createElement("div");
            const json = document.createElement("pre");
            label.className = "pdf-data-title";
            json.className = "pdf-json";
            label.textContent = index ? "RESPONSE" : "REQUEST";
            json.textContent = cells[index].textContent?.trim() || "";
            if (index) {
              const status = document.createElement("span");
              status.className = "pdf-http-status";
              status.textContent = cells[2].textContent?.trim() || "";
              label.append(status);
            }
            section.append(label, json);
            grid.append(section);
          });
          body.append(grid);
          step.remove();
          return;
        }

        const label = step.querySelector<HTMLElement>(":scope > .label");
        const marker = document.createElement("span");
        const failedStep = label?.classList.contains("label-danger");
        const skippedStep = label?.classList.contains("label-warning");
        marker.className = `pdf-step-status${(failedStep ? " failed" : undefined) ?? (skippedStep ? " skipped" : "")}`;
        marker.textContent = (failedStep ? "✗" : undefined) ?? (skippedStep ? "☐" : "✓");
        label?.replaceWith(marker);
      });

      body.querySelectorAll(".show-info, .modal").forEach((element) => element.remove());
      const top = heading.querySelector<HTMLElement>(".pdf-scenario-top");
      const card = document.createElement("div");
      card.className = "pdf-scenario-card";
      // NOSONAR(typescript:S7768): heading.before() rompe el render de los gráficos en el PDF; se mantiene insertBefore.
      if (top) panel.insertBefore(top, heading);
      panel.insertBefore(card, heading);
      card.append(heading, scenario);
    });
  });
}

export async function generarPDF(): Promise<void> {
  let browser;
  try {
    const raw = await fs.promises.readFile(PATHS.html, "utf8");
    const html = raw.includes('<meta charset="UTF-8">') ? raw : raw.replace(/<head>/i, '<head><meta charset="UTF-8">');
    browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
    const page = await browser.newPage();
    await page.emulateMedia({ media: "screen" });
    await page.setContent(html, { waitUntil: "networkidle" });
    await page.waitForSelector(".chart");
    await transformReport(page);
    await page.addStyleTag({ content: PDF_STYLES });
    await page.pdf({
      path: PATHS.pdf,
      scale: 0.65,
      format: "A4",
      printBackground: true,
      margin: { top: "25mm", bottom: "2cm" },
      displayHeaderFooter: true,
      headerTemplate: headerTemplate(logo, CONFIG.title!, CONFIG.application),
      footerTemplate: "<div></div>",
    });
    console.log(`PDF generado: ${PATHS.pdf}`);
  } catch (error) {
    console.error("Error generando el PDF:", error);
  } finally {
    await browser?.close();
  }
}

(async () => {
  await generarReporteHTML();
  await generarPDF();
  console.info("Reporte generado con éxito.");
})();
