import { IWorldOptions, setWorldConstructor, World } from "@cucumber/cucumber";

export class ApiWorld extends World {
  baseUrl = "";
  request?: { method: string; url: string; body?: unknown };
  response?: { status: number; body: unknown };
  startedAt?: Date;

  constructor(options: IWorldOptions) {
    super(options);
  }
}

setWorldConstructor(ApiWorld);
