import { After, AfterAll, Before, BeforeAll, Status, setDefaultTimeout } from "@cucumber/cucumber";
import type { ITestCaseHookParameter } from "@cucumber/cucumber";
import { startFakeApi, stopFakeApi } from "./fake-api";
import type { ApiWorld } from "./world";

setDefaultTimeout(30_000);

BeforeAll(async () => {
  await startFakeApi();
});

Before(function (this: ApiWorld, scenario: ITestCaseHookParameter) {
  this.startedAt = new Date();
  this.baseUrl = "http://127.0.0.1:3100";
  console.log(`Iniciando: ${scenario.pickle.name}`);
});

After(async function (this: ApiWorld, scenario: ITestCaseHookParameter) {
  const html = generarEvidenciaHtml({
    Request: JSON.stringify(this.request, null, 2),
    Response: JSON.stringify(this.response?.body, null, 2),
    Status: this.response?.status,
  });

  if (!html) throw new Error("HTML vacío generado");
  await this.attach(html, "text/html");

  const result = scenario.result?.status === Status.PASSED ? "PASSED" : scenario.result?.status;
  console.log(`Finalizado: ${scenario.pickle.name} - ${result}`);
});

AfterAll(async () => {
  await stopFakeApi();
});

function generarEvidenciaHtml(data: Record<string, unknown>): string {
  const headers = Object.keys(data);
  return `<html><head><style>
    body.bodyReport { font-family: 'Segoe UI', 'Roboto', 'Helvetica Neue', sans-serif; background-color: #f8f9fa; color: #212529; padding: 0; margin: 0; }
    .cardHtml { background: #fff; border-radius: 4px; padding: 1px; margin-bottom: 6px; }
    h2 { font-size: 13px; margin: 0; color: #343a40; }
    table { width: 100%; border-collapse: collapse; font-size: 11px; }
    th, td { border: 1px solid #e0e0e0; padding: 2px; }
    th { background-color: #f2f2f2; text-align: center; }
  </style></head><body class="bodyReport"><div class="cardHtml"><table>
    <thead><tr>${headers.map((header) => `<th>${header}</th>`).join("")}</tr></thead>
    <tbody><tr>${headers.map((header) => `<td>${data[header] ?? ""}</td>`).join("")}</tr></tbody>
  </table></div></body></html>`;
}
