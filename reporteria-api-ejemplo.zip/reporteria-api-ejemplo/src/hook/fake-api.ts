import { createServer, Server } from "node:http";

let server: Server | undefined;

export async function startFakeApi(): Promise<void> {
  if (server) return;

  server = createServer((request, response) => {
    response.setHeader("content-type", "application/json; charset=utf-8");

    if (request.method === "GET" && request.url === "/usuarios/1") {
      response.writeHead(200);
      response.end(JSON.stringify({ id: 1, nombre: "Ada Lovelace", activo: true }));
      return;
    }

    response.writeHead(404);
    response.end(JSON.stringify({ mensaje: "Recurso no encontrado" }));
  });

  await new Promise<void>((resolve, reject) => {
    server!.once("error", reject);
    server!.listen(3100, "127.0.0.1", resolve);
  });
}

export async function stopFakeApi(): Promise<void> {
  if (!server) return;
  const current = server;
  server = undefined;
  await new Promise<void>((resolve, reject) => current.close((error) => error ? reject(error) : resolve()));
}
